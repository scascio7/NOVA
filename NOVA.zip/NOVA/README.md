# NOVA - Numerical Omnitechnique Visualization and Analysis

One tkinter/matplotlib GUI for FTIR, Raman, UV-Vis, NMR, PXRD and generic XY data.
Blank/background subtraction, baseline correction, peak labelling, time-series (3D/heatmap) views, and
PXRD reference phases (.cif or .xy). Side-panel sections change with the selected technique.

## Install and run
```bash
git clone https://github.com/<you>/nova.git && cd nova
python3 -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt                           # add: pip install pymatgen   (for .cif)
python run_nova.py                                        # or: python -m nova
```
tkinter must be available (python.org installers include it; Homebrew: `brew install python-tk`).
Optional install as a command: `pip install -e .` then run `nova`.

## Data format
Column 1 = x (e.g. wavelength), further columns = one spectrum each (header = sample name).
.csv .txt .dat .xy .tsv .xlsx; header and junk lines are skipped.

## Layout
```
run_nova.py            launcher
nova/app.py            core window (dataset manager, preprocessing, visualisation, export)
nova/registry.py       technique repository (auto-discovery)
nova/techniques/       one module per technique: ftir, raman, uvvis, nmr, pxrd, xy (+ _template.py)
nova/features/         shared features: background, peaks, time axis
nova/processing.py     blank/baseline/smoothing/normalisation maths
nova/fileio.py         tolerant file reader
```

## Add a technique
Copy `nova/techniques/_template.py`, rename it, edit the class (axis labels, which sections to show).
It is picked up automatically at start-up.
