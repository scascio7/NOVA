"""NOVA - Numerical Omnitechnique Visualization and Analysis."""
