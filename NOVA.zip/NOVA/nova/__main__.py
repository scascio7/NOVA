"""Entry point:  python -m nova   (or the `nova` command after `pip install -e .`)."""
import tkinter as tk

from nova.app import create_app_class


def main():
    root = tk.Tk()
    create_app_class()(root)
    root.lift()
    root.mainloop()


if __name__ == "__main__":
    main()
