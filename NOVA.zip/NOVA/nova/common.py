"""Shared imports and constants (star-imported by every module)."""
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("TkAgg")
from matplotlib.figure import Figure
from matplotlib.gridspec import GridSpec
from matplotlib.collections import PolyCollection
from matplotlib.cm import ScalarMappable
from matplotlib.colors import Normalize, to_rgba
from matplotlib.ticker import AutoMinorLocator
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, colorchooser, simpledialog

try:
    from scipy.signal import savgol_filter, find_peaks
except ImportError:
    savgol_filter = find_peaks = None
try:
    from scipy import sparse
    from scipy.sparse.linalg import spsolve
    from scipy.interpolate import PchipInterpolator
except ImportError:
    sparse = spsolve = PchipInterpolator = None

PALETTE = ["#000000", "#d62728", "#006ED5", "#05be39", "#DB0BA0", "#E69F00", "#2ca02c", "#9467bd"]


MARKERS = "osv^D<>p"


# time (3rd dimension) is entered manually by the user, stored in seconds
UNIT = {"s": 1.0, "min": 60.0, "h": 3600.0, "d": 86400.0}


# UI look
BG, NAVY, ACCENT, INK, MUTED, LINE = "#f5f7fb", "#0b1f3a", "#2f6fed", "#1c2536", "#4a5568", "#d9dfeb"
FONT = "Helvetica Neue" if sys.platform == "darwin" else ("Segoe UI" if sys.platform.startswith("win") else "DejaVu Sans")
NUM = re.compile(r"^[-+]?(\d+\.?\d*|\.\d+)([eE][-+]?\d+)?$")
