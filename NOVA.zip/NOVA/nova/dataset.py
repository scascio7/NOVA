from nova.common import *


class Dataset:
    def __init__(self, x, y, label, color, kind="data", yerr=None):
        self.x, self.y, self.yerr = np.asarray(x, float), np.asarray(y, float), yerr
        self.label, self.color, self.kind = label, color, kind
        self.visible, self.is_blank = True, False
        self.xshift, self.yscale, self.bscale, self.blank = 0.0, 1.0, 1.0, None
        self.t = None  # time in seconds (3rd dimension)
        self.cif, self.hkl, self.ckey = None, None, None  # CIF-derived reference info
        self.marks = []  # manual peak labels: [x, text]
        self.ppm_offset = 0.0
        self.nmr_reference_peak = None
        self.nmr_reference_ppm = None


