"""Shared feature mixins (used by several techniques)."""
