from nova.common import *
from nova.processing import process, baseline, BG_MODES


class BackgroundMixin:
    SECTIONS = {"baseline": (50, "Baseline Correction", "build_baseline")}

    def build_baseline(self, b):
        self.combo(b, "Method", "bgmode", BG_MODES, "None")
        self.check(b, "Peaks point down (e.g. %T dips)", "bgdown")
        self.entry(b, "Poly order", "poly", "3")
        self.entry(b, "ALS λ (log10)", "als_lam", "6")
        self.entry(b, "ALS asymmetry", "als_p", "0.01")
        self.entry(b, "SNIP iterations", "snip_it", "40")
        self.entry(b, "Anchor x-values", "anchors", "")
        self.entry(b, "Reference x₀", "bgx0", "")
        self.check(b, "Clip negatives to 0", "bgclip")
        ttk.Button(b, text="Preview background...", command=self.preview_bg).pack(fill="x", pady=2)

    def preview_bg(self):
        """Pop-up: selected sample's signal, fitted background and corrected result."""
        i, d = self.cur()
        if d is None or d.kind != "data":
            return self.status("Select a sample in the dataset list to preview its background.", True)
        win = tk.Toplevel(self.root)
        win.title(f"Background preview - {d.label}"); win.configure(bg=BG); win.geometry("760x600")
        fig = Figure(figsize=(7, 5), dpi=100, facecolor="white")
        cv = FigureCanvasTkAgg(fig, master=win)
        NavigationToolbar2Tk(cv, win).pack(side="top", fill="x")

        def render():
            G = self.G()
            x, y, _ = process(d, dict(G, bgmode="None", bgclip=False, smooth=0, deriv=False, norm="None"))
            fig.clear()
            try:
                base = baseline(x, y, G)
            except Exception as e:
                fig.text(.5, .5, str(e), ha="center", color="#b00020"); cv.draw_idle(); return
            a1 = fig.add_subplot(211); a2 = fig.add_subplot(212, sharex=a1)
            a1.plot(x, y, color=INK, lw=1.2, label="Signal"); a1.plot(x, base, "--", color="#d62728", lw=1.5, label="Background")
            a1.legend(frameon=False)
            a2.plot(x, y - base, color=ACCENT, lw=1.2, label="Corrected"); a2.axhline(0, color="grey", lw=.6)
            a2.legend(frameon=False); a2.set_xlabel(G["xlabel"])
            if G["reverse"]: a1.invert_xaxis()
            fig.tight_layout(); cv.draw_idle()

        ttk.Button(win, text="Refresh with current settings", command=render).pack(side="bottom", fill="x", padx=8, pady=6)
        cv.get_tk_widget().pack(fill="both", expand=True)
        render()

