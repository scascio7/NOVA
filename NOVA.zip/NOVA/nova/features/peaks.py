from nova.common import *
from nova.processing import pick_peaks
from nova.registry import REGISTRY


def fmt_hkl(t):
    """'111' / '(1 -1 0)' / '-1,1,0' -> mathtext '$(1\\bar{1}0)$'. Anything else is shown as typed."""
    t = t.strip()
    if t.startswith("$"):
        return t
    core = t.strip("() ")
    if re.fullmatch(r"[-\d\s,]+", core):
        idx = re.findall(r"-?\d+", core) if re.search(r"[\s,]", core) else re.findall(r"-?\d", core)
        if len(idx) in (3, 4):
            return "$(" + "".join(("\\bar{%d}" % abs(int(i))) if int(i) < 0 else str(int(i)) for i in idx) + ")$"
    return t


class PeakMixin:
    SECTIONS = {"peaks": (60, "Peak Analysis", "build_peaks"), "labels": (80, "Peak Annotation", "build_labels")}

    def build_peaks(self, b):
        self.check(b, "Label peaks", "peaks")
        self.check(b, "Find minima (dips, e.g. %T)", "minima")
        self.entry(b, "Prominence (%)", "prom", "5")

    def build_labels(self, b):
        self.check(b, "Click plot to label peaks", "labelmode")
        ttk.Label(b, text="Left-click a peak: add / edit label.  Right-click a label: remove.\n"
                          "Type 111 or -1 1 0 for hkl; other text is shown as typed.", wraplength=300).pack(anchor="w")
        self.entry(b, "Rotation (°)", "markrot", "90")
        self.entry(b, "Match tol. (x units)", "mtol", "0.3")
        self.check(b, "Leader lines", "leader", True)
        bf = ttk.Frame(b); bf.pack(fill="x")
        ttk.Button(bf, text="Clear (selected)", command=lambda: self.clear_marks(False)).pack(side="left", expand=True, fill="x")
        ttk.Button(bf, text="Clear all", command=lambda: self.clear_marks(True)).pack(side="left", expand=True, fill="x")

    def _keep(self):
        if self.main_ax is not None:
            self._view = (self.main_ax.get_xlim(), self.main_ax.get_ylim())
        self.sched()

    def on_click(self, ev):
        ax = self.main_ax
        if (not self.on("labels") or not self.vars["labelmode"].get() or self.toolbar.mode != "" or ax is None or ev.inaxes is not ax
                or ev.xdata is None or not self.curves):
            return
        G = self.G()
        xl, yl = ax.get_xlim(), ax.get_ylim()
        xr, yr = abs(xl[1] - xl[0]), abs(yl[1] - yl[0])
        hit = None
        for d, x, y0, yp in self.curves:  # clicked on an existing label?
            for m in d.marks:
                if abs(m[0] - ev.xdata) < .012 * xr and x.min() <= m[0] <= x.max():
                    if abs(float(np.interp(m[0], x, yp)) + .06 * yr - ev.ydata) < .12 * yr:
                        hit = (d, m)
        if hit:
            d, m = hit
            if ev.button in (2, 3):
                d.marks.remove(m); return self._keep()
            t = simpledialog.askstring("Edit label", f"Label for peak at {m[0]:.2f} (blank = remove):",
                                       initialvalue=m[1], parent=self.root)
            if t is None:
                return
            if t.strip(): m[1] = t.strip()
            else: d.marks.remove(m)
            return self._keep()
        if ev.button != 1:
            return
        best = None  # trace closest to the click, then snap to its local peak
        for d, x, y0, yp in self.curves:
            if x.min() <= ev.xdata <= x.max():
                dist = abs(float(np.interp(ev.xdata, x, yp)) - ev.ydata)
                if best is None or dist < best[0]:
                    best = (dist, d, x, y0)
        if best is None:
            return
        _, d, x, y0 = best
        msk = np.abs(x - ev.xdata) <= .015 * xr
        if not msk.any():
            return
        xs, ys = x[msk], y0[msk]
        px = float(xs[np.argmin(ys) if G["minima"] else np.argmax(ys)])
        dec = max(REGISTRY[G["tech"]].decimals, 2)
        t = simpledialog.askstring("Label peak", f"Peak at {px:.{dec}f}\nReflection (e.g. 111 or -1 1 0):",
                                   initialvalue=self.suggest_hkl(px, G), parent=self.root)
        if t and t.strip():
            d.marks.append([px, t.strip()]); self._keep()

    def clear_marks(self, everything):
        i, d = self.cur()
        for o in (self.ds if everything else ([d] if d else [])):
            o.marks.clear()
        self._keep()

