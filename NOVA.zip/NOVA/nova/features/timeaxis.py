from nova.common import *
from nova.processing import process

TIME_MODES = ("3D", "Heatmap")


GRID_STYLES = ("Surface", "Wireframe", "Surface + contour", "Scatter points")


STYLES_3D = ("Waterfall (lines)", "Filled waterfall") + GRID_STYLES


class TimeMixin:
    SECTIONS = {"time": (100, "Time Series (3rd axis)", "build_time")}

    def build_time(self, b):
        self.check(b, "Use time as 3rd axis", "use_time", True)
        self.combo(b, "Time unit", "tunit", list(UNIT), "min")
        self.vars["tunit"].trace_add("write", lambda *_: self.on_select())
        self.entry(b, "Time label", "tlabel", "")
        self.entry(b, "Elevation", "elev", "25"); self.entry(b, "Azimuth", "azim", "-60")
        ttk.Button(b, text="Set times for all traces...", command=self.set_times).pack(fill="x", pady=2)

    def set_times(self):
        """Dialog: type a time for every trace (list order), or auto-fill start + step."""
        data = [d for d in self.ds if d.kind == "data" and not d.is_blank]
        if not data:
            return self.status("Load data first.", True)
        u = self.vars["tunit"].get(); U = UNIT[u]
        win = tk.Toplevel(self.root)
        win.title(f"Set times ({u})"); win.configure(bg=BG); win.transient(self.root); win.geometry("400x520")
        top = ttk.Frame(win, padding=8); top.pack(fill="x")
        st, sp = tk.StringVar(value="0"), tk.StringVar(value="10")
        for t, v in (("Start", st), ("Step", sp)):
            ttk.Label(top, text=t).pack(side="left"); ttk.Entry(top, textvariable=v, width=7).pack(side="left", padx=(3, 8))
        wrap = ttk.Frame(win); wrap.pack(fill="both", expand=True, padx=8)
        cv = tk.Canvas(wrap, bg=BG, highlightthickness=0); sb = ttk.Scrollbar(wrap, command=cv.yview)
        cv.configure(yscrollcommand=sb.set); sb.pack(side="right", fill="y"); cv.pack(side="left", fill="both", expand=True)
        body = ttk.Frame(cv); cv.create_window((0, 0), window=body, anchor="nw")
        body.bind("<Configure>", lambda e: cv.configure(scrollregion=cv.bbox("all")))
        rows = []
        for d in data:
            v = tk.StringVar(value="" if d.t is None else f"{d.t / U:g}")
            r = ttk.Frame(body); r.pack(fill="x", pady=2)
            ttk.Label(r, text=d.label[:30], width=30).pack(side="left")
            ttk.Entry(r, textvariable=v, width=9).pack(side="left")
            ttk.Label(r, text=u).pack(side="left", padx=4)
            rows.append((d, v))

        def fill():
            try:
                a, b = float(st.get()), float(sp.get())
            except ValueError:
                return
            for k, (_d, v) in enumerate(rows):
                v.set(f"{a + k * b:g}")

        def apply():
            for d, v in rows:
                t = v.get().strip()
                if t == "":
                    d.t = None
                else:
                    try: d.t = float(t) * U
                    except ValueError: pass
            win.destroy(); self.on_select(); self.sched()

        ttk.Button(top, text="Auto-fill", command=fill).pack(side="left")
        ttk.Button(win, text="Apply", style="Accent.TButton", command=apply).pack(fill="x", padx=8, pady=8)

    def draw_time(self, f, G, cur, colors):
        """3D (several styles) or heatmap with time (or trace index) as the 3rd axis."""
        mode, style, lw, U = G["mode"], G["style3d"], G["lw"], UNIT[G["tunit"]]
        have = bool(G["use_time"]) and all(c[0].t is not None for c in cur)
        order = sorted(range(len(cur)), key=lambda i: cur[i][0].t) if have else list(range(len(cur)))
        cur, colors = [cur[i] for i in order], [colors[i] for i in order]
        tv = np.array([c[0].t / U for c in cur]) if have else np.arange(len(cur), dtype=float)
        tlab = G["tlabel"] or (f"Time ({G['tunit']})" if have else "Trace #")
        grid = mode == "Heatmap" or style in GRID_STYLES
        if grid and len(cur) < 2:
            return self.status(f"{'Heatmap' if mode == 'Heatmap' else style} needs at least 2 visible traces.", True)
        cm = "viridis" if G["cmap"] == "Custom colours" else G["cmap"]
        if grid:
            xg = np.linspace(max(c[1].min() for c in cur), min(c[1].max() for c in cur), max(len(c[1]) for c in cur))
            Z = np.array([np.interp(xg, c[1], c[2]) for c in cur])
        if mode == "Heatmap":
            ax = f.add_subplot(111)
            f.colorbar(ax.pcolormesh(xg, tv, Z, shading="auto", cmap=cm), ax=ax, label=G["ylabel"])
        else:
            ax, m = f.add_subplot(111, projection="3d"), None
            if style == "Waterfall (lines)":
                for i, (d, x, y, _e) in enumerate(cur):
                    ax.plot(x, np.full_like(x, tv[i]), y, color=colors[i], lw=lw)
            elif style == "Filled waterfall":
                zmin = min(c[2].min() for c in cur)
                for i, (d, x, y, _e) in enumerate(cur):
                    verts = [[(x[0], zmin), *zip(x, y), (x[-1], zmin)]]
                    ax.add_collection3d(PolyCollection(verts, facecolors=[to_rgba(colors[i], .55)],
                                                       edgecolors=[colors[i]], linewidths=lw), zs=tv[i], zdir="y")
                pad = (np.ptp(tv) or 1) * .05
                ax.set_xlim(min(c[1].min() for c in cur), max(c[1].max() for c in cur))
                ax.set_ylim(tv.min() - pad, tv.max() + pad); ax.set_zlim(zmin, max(c[2].max() for c in cur))
            else:
                X, T = np.meshgrid(xg, tv)
                if style == "Surface":
                    m = ax.plot_surface(X, T, Z, cmap=cm, linewidth=0, antialiased=True)
                elif style == "Wireframe":
                    ax.plot_wireframe(X, T, Z, color="#1f3a63", linewidth=.6, rstride=1, cstride=max(1, len(xg) // 80))
                elif style == "Surface + contour":
                    m = ax.plot_surface(X, T, Z, cmap=cm, alpha=.85, linewidth=0)
                    ax.contourf(X, T, Z, zdir="z", offset=Z.min(), cmap=cm, alpha=.8)
                else:
                    k = max(1, Z.size // 6000)
                    m = ax.scatter(X.ravel()[::k], T.ravel()[::k], Z.ravel()[::k], c=Z.ravel()[::k], cmap=cm, s=4)
            if m is not None:
                f.colorbar(m, ax=ax, shrink=.6, pad=.1, label=G["ylabel"])
            ax.set_zlabel(G["ylabel"])
            if not have:
                ax.set_yticks(tv); ax.set_yticklabels([c[0].label for c in cur], fontsize=G["font"] - 4)
            ax.view_init(elev=G["elev"], azim=G["azim"])
        ax.set_xlabel(G["xlabel"]); ax.set_ylabel(tlab)
        if G["reverse"]: ax.invert_xaxis()
        try: f.tight_layout()
        except Exception: pass
        self.cv.draw_idle()
        self.status(f"{len(cur)} traces | {'Heatmap' if mode == 'Heatmap' else '3D: ' + style} | "
                    f"3rd axis: {tlab if have else 'trace order (set times in the Time section)'}")

