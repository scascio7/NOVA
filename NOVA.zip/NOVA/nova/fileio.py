from nova.common import *


MISSING = {"", "nan", "na", "n/a", "null", "-"}


def read_any(path):
    """-> x (n,), Y (n,k), names [k or None].
    Standard layout: column 1 = x (e.g. wavelength), every other column = one sample (header = sample name).
    Tolerates header/junk lines, empty cells (-> NaN) and numeric headers (e.g. times)."""
    p = Path(path)
    if p.suffix.lower() in (".xlsx", ".xlsm", ".xls"):
        rows = [["" if pd.isna(v) else v for v in r] for r in pd.read_excel(p, header=None).itertuples(index=False)]
    else:
        def split(ln):
            ln = ln.rstrip("\r\n")
            if "\t" in ln:
                return [t.strip() for t in ln.split("\t")]
            if "," in ln or ";" in ln:
                return [t.strip() for t in re.split(r"[,;]", ln)]
            return ln.split()
        rows = [split(ln) for ln in p.read_bytes().decode("utf-8-sig", errors="replace").splitlines()]
    ok = lambda t: str(t).strip().lower() in MISSING or NUM.match(str(t).strip())
    isnum = lambda r: len(r) >= 2 and NUM.match(str(r[0]).strip()) and all(ok(t) for t in r[1:])
    data = [r for r in rows if isnum(r)]
    if not data:
        raise ValueError("No numeric data found. Expected: column 1 = x, further columns = samples.")
    lens = [len(r) for r in data]
    k = max(set(lens), key=lens.count)
    first = next(i for i, r in enumerate(rows) if isnum(r) and len(r) == k)
    f = lambda t: float(t) if NUM.match(str(t).strip()) else np.nan
    A = np.array([[f(t) for t in r] for r in data if len(r) == k])
    names = [None] * (k - 1)
    hdr = [str(t).strip() for t in rows[first - 1]] if first > 0 else []
    if len(hdr) == k:
        names = [h or None for h in hdr[1:]]
    if A.shape[0] > 3:  # numeric header row (e.g. 0, 5, 10, 15 min)?
        dx = np.median(np.abs(np.diff(A[1:, 0])))
        if dx > 0 and abs(A[1, 0] - A[0, 0]) > 10 * dx:
            names = [f"{v:g}" if np.isfinite(v) else None for v in A[0, 1:]]
            A = A[1:]
    order = np.argsort(A[:, 0])
    return A[order, 0], A[order, 1:], names


