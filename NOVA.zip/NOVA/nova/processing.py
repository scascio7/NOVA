from nova.common import *


def modpoly(x, y, n, it=50):
    xs, yy = (x - x.mean()) / (np.ptp(x) or 1), y.copy()
    for _ in range(it):
        yy = np.minimum(yy, np.polyval(np.polyfit(xs, yy, n), xs))
    return np.polyval(np.polyfit(xs, yy, n), xs)


BG_MODES = ["None", "Offset to min", "Constant at x₀", "Linear (endpoints)", "Polynomial", "Rubberband",
            "SNIP", "ALS (asymmetric LS)", "Anchor points"]


def rubberband(x, y):
    """Lower convex hull of the spectrum (x ascending)."""
    h = []
    for i in range(len(x)):
        while len(h) >= 2 and (y[h[-1]] - y[h[-2]]) * (x[i] - x[h[-2]]) >= (y[i] - y[h[-2]]) * (x[h[-1]] - x[h[-2]]):
            h.pop()
        h.append(i)
    return np.interp(x, x[h], y[h])


def snip(y, iters):
    """SNIP clipping baseline (good for XRD / Raman)."""
    y0 = y.min()
    w = np.log(np.log(np.sqrt(y - y0 + 1) + 1) + 1)
    for p in range(1, int(iters) + 1):
        if 2 * p >= len(w): break
        a = w.copy()
        a[p:-p] = np.minimum(w[p:-p], (w[:-2 * p] + w[2 * p:]) / 2)
        w = a
    return (np.exp(np.exp(w) - 1) - 1) ** 2 - 1 + y0


def als(x, y, lam, p, it=10):
    """Asymmetric least squares (Eilers & Boelens). Falls back to a polynomial without scipy."""
    if sparse is None:
        return modpoly(x, y, 5)
    n = len(y)
    D = sparse.diags([1.0, -2.0, 1.0], [0, -1, -2], shape=(n, n - 2))
    DD, w = lam * D.dot(D.T), np.ones(n)
    for _ in range(it):
        z = spsolve((sparse.spdiags(w, 0, n, n) + DD).tocsc(), w * y)
        w = p * (y > z) + (1 - p) * (y < z)
    return z


def baseline(x, y, G):
    """Background estimate for one spectrum, according to the chosen method."""
    m, sg = G["bgmode"], (-1.0 if G["bgdown"] else 1.0)
    yy = sg * y
    if m == "None":
        return np.zeros_like(y)
    if m == "Offset to min":
        b = np.full_like(yy, yy.min())
    elif m.startswith("Constant"):
        if G["bgx0"] is None:
            raise ValueError("Background: enter a reference x\u2080 value.")
        b = np.full_like(yy, yy[np.argmin(np.abs(x - G["bgx0"]))])
    elif m.startswith("Linear"):
        k = max(1, min(3, len(x) // 10))
        b = np.polyval(np.polyfit([x[:k].mean(), x[-k:].mean()], [yy[:k].mean(), yy[-k:].mean()], 1), x)
    elif m == "Polynomial":
        b = modpoly(x, yy, int(G["poly"]))
    elif m == "Rubberband":
        b = rubberband(x, yy)
    elif m == "SNIP":
        b = snip(yy, G["snip_it"])
    elif m.startswith("ALS"):
        b = als(x, yy, 10 ** G["als_lam"], G["als_p"])
    else:  # Anchor points
        a = sorted(float(t) for t in re.split(r"[,;\s]+", G["anchors"].strip()) if NUM.match(t))
        if len(a) < 2:
            raise ValueError("Background: enter at least 2 anchor x-values (comma-separated).")
        idx = [int(np.argmin(np.abs(x - v))) for v in a]
        ax_, ay_ = x[idx], np.array([yy[max(i - 2, 0):i + 3].mean() for i in idx])
        keep = np.concatenate([[True], np.diff(ax_) > 0])
        b = (PchipInterpolator(ax_[keep], ay_[keep])(x) if PchipInterpolator and keep.sum() > 2
             else np.interp(x, ax_[keep], ay_[keep]))
    return sg * b


def pick_peaks(y, prom, minima=False):
    s = -y if minima else y
    if find_peaks:
        return find_peaks(s, prominence=prom)[0]
    i = np.where((s[1:-1] > s[:-2]) & (s[1:-1] >= s[2:]) & (s[1:-1] - s.min() > prom))[0] + 1
    return i


def process(d, G):

    ppm_offset = (
        getattr(d, "ppm_offset", 0.0)
        if G["tech"] == "NMR"
        else 0.0
    )

    x = d.x + d.xshift + ppm_offset
    y = d.y.copy()
    e = d.yerr

    b = d.blank

    if b is not None and b is not d:

        bg_offset = (
            getattr(b, "ppm_offset", 0.0)
            if G["tech"] == "NMR"
            else 0.0
        )

        y = y - d.bscale * np.interp(
            x,
            b.x + b.xshift + bg_offset,
            b.y
        )
    if G["convert"].startswith("%T"):
        y = -np.log10(np.clip(y, 1e-6, None) / 100)
    elif G["convert"].startswith("Abs"):
        y = 100 * 10 ** (-y)
    m = np.ones(len(x), bool)
    if G["xmin"] is not None: m &= x >= G["xmin"]
    if G["xmax"] is not None: m &= x <= G["xmax"]
    if m.sum() < 3:
        raise ValueError(f"X-range leaves <3 points for '{d.label}'.")
    x, y = x[m], y[m]
    e = None if e is None else np.asarray(e)[m]
    y = y - baseline(x, y, G)
    if G["bgclip"]:
        y = np.clip(y, 0, None)
    w = int(G["smooth"])
    if w >= 3:
        w += (w % 2 == 0)
        w = min(w, len(y) - (len(y) % 2 == 0))
        y = savgol_filter(y, w, min(3, w - 1)) if savgol_filter else np.convolve(y, np.ones(w) / w, "same")
    if G["deriv"]:
        y = np.gradient(y, x)
    nm = G["norm"]
    if nm == "Max":
        y = y / (np.abs(y).max() or 1)
    elif nm == "Min-max":
        y = (y - y.min()) / (np.ptp(y) or 1)
    elif nm == "Area":
        y = y / (abs(np.sum(np.abs(np.diff(x)) * (y[:-1] + y[1:]) / 2)) or 1)
    y = y * d.yscale
    return x, y, e


