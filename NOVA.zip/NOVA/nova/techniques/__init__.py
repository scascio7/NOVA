"""Technique plugins: one module per technique (auto-discovered)."""
