"""Template: copy to nova/techniques/mytech.py (files starting with _ are ignored) and edit."""
from nova.registry import Technique, register


@register
class MyTechnique(Technique):
    name, order = "MyTech", 70
    xlabel, ylabel = "X (units)", "Signal (a.u.)"
    sections = frozenset({"baseline", "peaks", "labels"})   # optional side-panel sections to show
    # mixin = MyMixin   # optional: class with SECTIONS = {id: (order, title, builder_method)} and extra methods
